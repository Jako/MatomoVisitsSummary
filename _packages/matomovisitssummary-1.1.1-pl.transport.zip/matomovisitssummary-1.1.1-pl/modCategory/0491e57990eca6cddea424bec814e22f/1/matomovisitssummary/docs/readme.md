# MatomoVisitsSummary

A MODX Dashboard Widget with the visits summary graph of Matomo

- Author: Christian Seel <hallo@chsmedien.de>, https://chsmedien.de
- Current Maintainer: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

This extra brings the Matomo VisitsSummary Graph to your MODX Dashboard. The
package also includes a chunk with the matomo tracking code.

## Installation

MODX Package Management

## GitHub Repository

https://github.com/Jako/MatomoVisitsSummary
